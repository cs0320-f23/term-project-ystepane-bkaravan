import {
  require_react
} from "/node_modules/.vite/deps/chunk-DL3EQQMX.js?v=3ba690a6";
export default require_react();
//# sourceMappingURL=react.js.map
