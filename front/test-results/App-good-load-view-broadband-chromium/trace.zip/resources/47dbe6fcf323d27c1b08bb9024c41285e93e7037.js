import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba690a6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function ControlledInput({
  value,
  setValue,
  ariaLabel
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "Enter command here!", onChange: (ev) => setValue(ev.target.value), "aria-label": ariaLabel }, void 0, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/ControlledInput.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJJO0FBckJKLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZXBCLGdCQUFTQSxnQkFBZ0I7QUFBQSxFQUM5QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDb0IsR0FBRztBQUN2QixTQUNFLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLFdBQVUsb0JBQ1YsT0FDQSxhQUFZLHVCQUNaLFVBQVdDLFFBQU9GLFNBQVNFLEdBQUdDLE9BQU9KLEtBQUssR0FDMUMsY0FBWUUsYUFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0M7QUFFTDtBQUFDRyxLQWZlTjtBQUFlLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDb250cm9sbGVkSW5wdXQiLCJ2YWx1ZSIsInNldFZhbHVlIiwiYXJpYUxhYmVsIiwiZXYiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyb2xsZWRJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XHJcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuLy8gUmVtZW1iZXIgdGhhdCBwYXJhbWV0ZXIgbmFtZXMgZG9uJ3QgbmVjZXNzYXJpbHkgbmVlZCB0byBvdmVybGFwO1xyXG4vLyBJIGNvdWxkIHVzZSBkaWZmZXJlbnQgdmFyaWFibGUgbmFtZXMgaW4gdGhlIGFjdHVhbCBmdW5jdGlvbi5cclxuaW50ZXJmYWNlIENvbnRyb2xsZWRJbnB1dFByb3BzIHtcclxuICB2YWx1ZTogc3RyaW5nO1xyXG4gIC8vIFRoaXMgdHlwZSBjb21lcyBmcm9tIFJlYWN0K1R5cGVTY3JpcHQuIFZTQ29kZSBjYW4gc3VnZ2VzdCB0aGVzZS5cclxuICAvLyAgIENvbmNyZXRlbHksIHRoaXMgbWVhbnMgXCJhIGZ1bmN0aW9uIHRoYXQgc2V0cyBhIHN0YXRlIGNvbnRhaW5pbmcgYSBzdHJpbmdcIlxyXG4gIHNldFZhbHVlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PjtcclxuICBhcmlhTGFiZWw6IHN0cmluZztcclxufVxyXG5cclxuLy8gSW5wdXQgYm94ZXMgY29udGFpbiBzdGF0ZS4gV2Ugd2FudCB0byBtYWtlIHN1cmUgUmVhY3QgaXMgbWFuYWdpbmcgdGhhdCBzdGF0ZSxcclxuLy8gICBzbyB3ZSBoYXZlIGEgc3BlY2lhbCBjb21wb25lbnQgdGhhdCB3cmFwcyB0aGUgaW5wdXQgYm94LlxyXG5leHBvcnQgZnVuY3Rpb24gQ29udHJvbGxlZElucHV0KHtcclxuICB2YWx1ZSxcclxuICBzZXRWYWx1ZSxcclxuICBhcmlhTGFiZWwsXHJcbn06IENvbnRyb2xsZWRJbnB1dFByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxpbnB1dFxyXG4gICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgIGNsYXNzTmFtZT1cInJlcGwtY29tbWFuZC1ib3hcIlxyXG4gICAgICB2YWx1ZT17dmFsdWV9XHJcbiAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgY29tbWFuZCBoZXJlIVwiXHJcbiAgICAgIG9uQ2hhbmdlPXsoZXYpID0+IHNldFZhbHVlKGV2LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgIGFyaWEtbGFiZWw9e2FyaWFMYWJlbH1cclxuICAgID48L2lucHV0PlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9rYXJhdi9PbmVEcml2ZS9Eb2N1bWVudHMvQ1MzMi9yZXBsLWJrYXJhdmFuLXlzdGVwYW5lL2Zyb250L3NyYy9jb21wb25lbnRzL0NvbnRyb2xsZWRJbnB1dC50c3gifQ==