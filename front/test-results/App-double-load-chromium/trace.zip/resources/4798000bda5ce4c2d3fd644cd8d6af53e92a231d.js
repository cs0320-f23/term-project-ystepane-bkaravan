import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba690a6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=3ba690a6"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { data, searchdata } from "/src/components/MockData.tsx";
import { commandHandler } from "/src/components/REPLFunction.tsx";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(Number);
  const [mode, setMode] = useState(true);
  const [mock, setMock] = useState(false);
  async function handleSubmit(commandString2) {
    let viewFlag = false;
    setCount(count + 1);
    let output = "Output: ";
    let result = [[]];
    let splitInput = commandString2.split(" ");
    if (splitInput[0] == "mock") {
      setMock(!mock);
      if (mock) {
        output += "real server";
      } else {
        output += "mock server";
      }
    } else {
      if (!mock) {
        if (splitInput[0] == "mode") {
          setMode(!mode);
          output += handleMode(mode);
        } else {
          let response = await commandHandler(splitInput[0], splitInput.slice(1));
          output += response[0];
          result = response[1];
        }
      } else {
        switch (splitInput[0]) {
          case "mode": {
            setMode(!mode);
            output += handleMode(mode);
            break;
          }
          case "load_file": {
            if (splitInput.length != 2) {
              output += "Error: bad filepath!";
            } else {
              if (handleLoad(splitInput[1], props)) {
                output = output + "load_file of " + splitInput[1] + " successful!";
              } else {
                output = output + "Could not find " + splitInput[1];
              }
            }
            break;
          }
          case "view": {
            if (splitInput.length != 1) {
              output += "Error: view only takes in 1 argument. Take cs32 again!";
            } else {
              if (props.file[0].length !== 0) {
                viewFlag = true;
                output += "Successful view!";
              } else {
                output += "Error: no files were loaded.";
              }
            }
            break;
          }
          case "search": {
            if (splitInput.length !== 3) {
              output += "Error: search needs three args";
            } else {
              if (props.file[0].length !== 0) {
                result = handleSearch(splitInput[1], splitInput[2]);
                output += "Searching! :)";
              } else {
                output += "Error: search requires a load";
              }
            }
            break;
          }
          default: {
            output = output + "Error: bad command. " + commandString2 + " is not a real command";
            break;
          }
        }
      }
    }
    handleOutput(props, mode, output, splitInput, result, viewFlag);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLInput.tsx",
        lineNumber: 146,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLInput.tsx",
        lineNumber: 147,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLInput.tsx",
      lineNumber: 145,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: () => handleSubmit(commandString),
        children: [
          "Submitted ",
          count,
          " times"
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLInput.tsx",
        lineNumber: 149,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLInput.tsx",
    lineNumber: 144,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "rWQB79ZugqlbpjRFqV8zVCkNC1U=");
_c = REPLInput;
export function handleLoad(pathFile, props) {
  let file = data.get(pathFile);
  if (file !== void 0) {
    props.setFile(file);
    return true;
  }
  return false;
}
export function handleMode(state) {
  let output = "Mode switched to ";
  if (state) {
    output += "verbose";
  } else {
    output += "brief";
  }
  return output;
}
export function handleSearch(arg1, arg2) {
  let result = searchdata.get(arg1 + arg2);
  if (result !== void 0) {
    return result;
  }
  return [["Error: ", "search", "failed. ", " Keyword", "not ", "found."], ["Args", arg1, arg2]];
}
export function handleOutput(props, mode, output, command, result, viewflag) {
  let outputArray;
  let newCommand = ["Command: "].concat(command);
  outputArray = [newCommand];
  outputArray = outputArray.concat([output.split(" ")]);
  outputArray = outputArray.concat(result);
  if (viewflag) {
    outputArray = outputArray.concat(props.file);
  }
  if (mode) {
    props.setHistory([...props.commands, outputArray.slice(1)]);
  } else {
    props.setHistory([...props.commands, outputArray]);
  }
}
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkpROzs7Ozs7Ozs7Ozs7Ozs7OztBQTNKUixPQUFPO0FBQ1AsU0FJRUEsZ0JBRUs7QUFDUCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsTUFBTUMsa0JBQWtCO0FBQ2pDLFNBQVNDLHNCQUFzQjtBQWlCeEIsZ0JBQVNDLFVBQVVDLE9BQXVCO0FBQUFDLEtBQUE7QUFDL0MsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVQsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUNVLE9BQU9DLFFBQVEsSUFBSVgsU0FBU1ksTUFBTTtBQUN6QyxRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSWQsU0FBa0IsSUFBSTtBQUM5QyxRQUFNLENBQUNlLE1BQU1DLE9BQU8sSUFBSWhCLFNBQWtCLEtBQUs7QUFzQi9DLGlCQUFlaUIsYUFBYVQsZ0JBQXVCO0FBQ2pELFFBQUlVLFdBQVc7QUFDZlAsYUFBU0QsUUFBUSxDQUFDO0FBQ2xCLFFBQUlTLFNBQVM7QUFDYixRQUFJQyxTQUFxQixDQUFDLEVBQUU7QUFDNUIsUUFBSUMsYUFBYWIsZUFBY2MsTUFBTSxHQUFHO0FBRXhDLFFBQUlELFdBQVcsQ0FBQyxLQUFLLFFBQVE7QUFDM0JMLGNBQVEsQ0FBQ0QsSUFBSTtBQUNiLFVBQUlBLE1BQU07QUFDUkksa0JBQVU7QUFBQSxNQUNaLE9BQU87QUFDTEEsa0JBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRixPQUFPO0FBR0wsVUFBSSxDQUFDSixNQUFNO0FBQ1QsWUFBSU0sV0FBVyxDQUFDLEtBQUssUUFBUTtBQUMzQlAsa0JBQVEsQ0FBQ0QsSUFBSTtBQUNiTSxvQkFBVUksV0FBV1YsSUFBSTtBQUFBLFFBQzNCLE9BQU87QUFDTCxjQUFJVyxXQUFXLE1BQU1wQixlQUNuQmlCLFdBQVcsQ0FBQyxHQUNaQSxXQUFXSSxNQUFNLENBQUMsQ0FDcEI7QUFDQU4sb0JBQVVLLFNBQVMsQ0FBQztBQUNwQkosbUJBQVNJLFNBQVMsQ0FBQztBQUFBLFFBQ3JCO0FBQUEsTUFDRixPQUFPO0FBSUwsZ0JBQVFILFdBQVcsQ0FBQyxHQUFDO0FBQUEsVUFDbkIsS0FBSyxRQUFRO0FBQ1hQLG9CQUFRLENBQUNELElBQUk7QUFDYk0sc0JBQVVJLFdBQVdWLElBQUk7QUFDekI7QUFBQSxVQUNGO0FBQUEsVUFDQSxLQUFLLGFBQWE7QUFDaEIsZ0JBQUlRLFdBQVdLLFVBQVUsR0FBRztBQUMxQlAsd0JBQVU7QUFBQSxZQUNaLE9BQU87QUFDTCxrQkFBSVEsV0FBV04sV0FBVyxDQUFDLEdBQUdmLEtBQUssR0FBRztBQUNwQ2EseUJBQ0VBLFNBQVMsa0JBQWtCRSxXQUFXLENBQUMsSUFBSTtBQUFBLGNBQy9DLE9BQU87QUFDTEYseUJBQVNBLFNBQVMsb0JBQW9CRSxXQUFXLENBQUM7QUFBQSxjQUNwRDtBQUFBLFlBQ0Y7QUFDQTtBQUFBLFVBQ0Y7QUFBQSxVQUNBLEtBQUssUUFBUTtBQUVYLGdCQUFJQSxXQUFXSyxVQUFVLEdBQUc7QUFDMUJQLHdCQUNFO0FBQUEsWUFFSixPQUFPO0FBQ0wsa0JBQUliLE1BQU1zQixLQUFLLENBQUMsRUFBRUYsV0FBVyxHQUFHO0FBRTlCUiwyQkFBVztBQUNYQywwQkFBVTtBQUFBLGNBQ1osT0FBTztBQUNMQSwwQkFBVTtBQUFBLGNBQ1o7QUFBQSxZQUNGO0FBQ0E7QUFBQSxVQUNGO0FBQUEsVUFDQSxLQUFLLFVBQVU7QUFDYixnQkFBSUUsV0FBV0ssV0FBVyxHQUFHO0FBQzNCUCx3QkFBVTtBQUFBLFlBQ1osT0FBTztBQUNMLGtCQUFJYixNQUFNc0IsS0FBSyxDQUFDLEVBQUVGLFdBQVcsR0FBRztBQUM5Qk4seUJBQVNTLGFBQWFSLFdBQVcsQ0FBQyxHQUFHQSxXQUFXLENBQUMsQ0FBQztBQUNsREYsMEJBQVU7QUFBQSxjQUNaLE9BQU87QUFDTEEsMEJBQVU7QUFBQSxjQUNaO0FBQUEsWUFDRjtBQUNBO0FBQUEsVUFDRjtBQUFBLFVBQ0EsU0FBUztBQUNQQSxxQkFDRUEsU0FDQSx5QkFDQVgsaUJBQ0E7QUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFHQXNCLGlCQUFheEIsT0FBT08sTUFBTU0sUUFBUUUsWUFBWUQsUUFBUUYsUUFBUTtBQUM5RFQscUJBQWlCLEVBQUU7QUFBQSxFQUNyQjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQkFBQyxjQUNDO0FBQUEsNkJBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsTUFDeEIsdUJBQUMsbUJBQ0MsT0FBT0QsZUFDUCxVQUFVQyxrQkFDVixXQUFXLG1CQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHNkI7QUFBQSxTQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLE1BQU1RLGFBQWFULGFBQWE7QUFBQSxRQUUxQztBQUFBO0FBQUEsVUFDWUU7QUFBQUEsVUFBTTtBQUFBO0FBQUE7QUFBQSxNQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLQTtBQUFBLE9BZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBRUo7QUFDQUgsR0FoSmdCRixXQUFTO0FBQUEwQixLQUFUMUI7QUFtSlQsZ0JBQVNzQixXQUFXSyxVQUFrQjFCLE9BQWdDO0FBQzNFLE1BQUlzQixPQUFPMUIsS0FBSytCLElBQUlELFFBQVE7QUFDNUIsTUFBSUosU0FBU00sUUFBVztBQUN0QjVCLFVBQU02QixRQUFRUCxJQUFJO0FBQ2xCLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTztBQUNUO0FBTU8sZ0JBQVNMLFdBQVdhLE9BQXdCO0FBQ2pELE1BQUlqQixTQUFTO0FBQ2IsTUFBSWlCLE9BQU87QUFDVGpCLGNBQVU7QUFBQSxFQUNaLE9BQU87QUFDTEEsY0FBVTtBQUFBLEVBQ1o7QUFDQSxTQUFPQTtBQUNUO0FBS08sZ0JBQVNVLGFBQWFRLE1BQWNDLE1BQTBCO0FBQ25FLE1BQUlsQixTQUFTakIsV0FBVzhCLElBQUlJLE9BQU9DLElBQUk7QUFDdkMsTUFBSWxCLFdBQVdjLFFBQVc7QUFDeEIsV0FBT2Q7QUFBQUEsRUFDVDtBQUNBLFNBQU8sQ0FDTCxDQUFDLFdBQVcsVUFBVSxZQUFZLFlBQVksUUFBUSxRQUFRLEdBQzlELENBQUMsUUFBUWlCLE1BQU1DLElBQUksQ0FBQztBQUV4QjtBQUlPLGdCQUFTUixhQUNkeEIsT0FDQU8sTUFDQU0sUUFDQW9CLFNBQ0FuQixRQUNBb0IsVUFDTTtBQUNOLE1BQUlDO0FBQ0osTUFBSUMsYUFBYSxDQUFDLFdBQVcsRUFBRUMsT0FBT0osT0FBTztBQUM3Q0UsZ0JBQWMsQ0FBQ0MsVUFBVTtBQUN6QkQsZ0JBQWNBLFlBQVlFLE9BQU8sQ0FBQ3hCLE9BQU9HLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFFcERtQixnQkFBY0EsWUFBWUUsT0FBT3ZCLE1BQU07QUFDdkMsTUFBSW9CLFVBQVU7QUFDWkMsa0JBQWNBLFlBQVlFLE9BQU9yQyxNQUFNc0IsSUFBSTtBQUFBLEVBQzdDO0FBRUEsTUFBSWYsTUFBTTtBQUVSUCxVQUFNc0MsV0FBVyxDQUFDLEdBQUd0QyxNQUFNdUMsVUFBVUosWUFBWWhCLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFBQSxFQUM1RCxPQUFPO0FBRUxuQixVQUFNc0MsV0FBVyxDQUFDLEdBQUd0QyxNQUFNdUMsVUFBVUosV0FBVyxDQUFDO0FBQUEsRUFDbkQ7QUFDRjtBQUFDLElBQUFWO0FBQUFlLGFBQUFmLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsImRhdGEiLCJzZWFyY2hkYXRhIiwiY29tbWFuZEhhbmRsZXIiLCJSRVBMSW5wdXQiLCJwcm9wcyIsIl9zIiwiY29tbWFuZFN0cmluZyIsInNldENvbW1hbmRTdHJpbmciLCJjb3VudCIsInNldENvdW50IiwiTnVtYmVyIiwibW9kZSIsInNldE1vZGUiLCJtb2NrIiwic2V0TW9jayIsImhhbmRsZVN1Ym1pdCIsInZpZXdGbGFnIiwib3V0cHV0IiwicmVzdWx0Iiwic3BsaXRJbnB1dCIsInNwbGl0IiwiaGFuZGxlTW9kZSIsInJlc3BvbnNlIiwic2xpY2UiLCJsZW5ndGgiLCJoYW5kbGVMb2FkIiwiZmlsZSIsImhhbmRsZVNlYXJjaCIsImhhbmRsZU91dHB1dCIsIl9jIiwicGF0aEZpbGUiLCJnZXQiLCJ1bmRlZmluZWQiLCJzZXRGaWxlIiwic3RhdGUiLCJhcmcxIiwiYXJnMiIsImNvbW1hbmQiLCJ2aWV3ZmxhZyIsIm91dHB1dEFycmF5IiwibmV3Q29tbWFuZCIsImNvbmNhdCIsInNldEhpc3RvcnkiLCJjb21tYW5kcyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XHJcbmltcG9ydCB7XHJcbiAgRGlzcGF0Y2gsXHJcbiAgU2V0U3RhdGVBY3Rpb24sXHJcbiAgaXNWYWxpZEVsZW1lbnQsXHJcbiAgdXNlU3RhdGUsXHJcbiAgdXNlRWZmZWN0LFxyXG59IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcclxuaW1wb3J0IHsgZGF0YSwgc2VhcmNoZGF0YSB9IGZyb20gXCIuL01vY2tEYXRhXCI7XHJcbmltcG9ydCB7IGNvbW1hbmRIYW5kbGVyIH0gZnJvbSBcIi4vUkVQTEZ1bmN0aW9uXCI7XHJcbi8qXHJcbiAqIFRoaXMgY29tcG9uZW50IGlzIHJlc3BvbnNpYmxlIGZvciBtYW5hZ2luZyB0aGUgaW5wdXQgZnJvbSB0aGUgcGFnZSwgYXMgd2VsbCBhcyBwcm9jZXNzaW5nIHRoZSBhdmFpYWxiZSBjb21tYW5kcy5cclxuICovXHJcbi8qXHJcbiAqIFRoaXMgaW50ZXJmYWNlIGluY2x1ZGVzIHRoZSBwcm9wcyB1c2VkIGJlbG93LlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBSRVBMSW5wdXRQcm9wcyB7XHJcbiAgY29tbWFuZHM6IHN0cmluZ1tdW11bXTtcclxuICBmaWxlOiBzdHJpbmdbXVtdO1xyXG4gIHNldEZpbGU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZ1tdW10+PjtcclxuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmdbXVtdW10+PjtcclxufVxyXG5cclxuLypcclxuICogVGhpcyBmdW5jdGlvbiBzZXRzIHRoZSBuZWVkZWQgY29uc3QgdG8gdXNlU3RhdGUuXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gUkVQTElucHV0KHByb3BzOiBSRVBMSW5wdXRQcm9wcykge1xyXG4gIGNvbnN0IFtjb21tYW5kU3RyaW5nLCBzZXRDb21tYW5kU3RyaW5nXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XHJcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZShOdW1iZXIpO1xyXG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xyXG4gIGNvbnN0IFttb2NrLCBzZXRNb2NrXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcclxuICAvKlxyXG4gICAqIFRoaXMgZnVuY3Rpb24gaGFuZGxlcyB0aGUgc3VibWlzc2lvbiBlbnRlcmVkIGJ5IHRoZSB1c2VyLlxyXG4gICAqIFRoZXJlIGlzIGEgc3dpdGNoIGNhc2UgdGhhdCB3b3JrcyB3aXRoIGEgc3BsaXR0ZWQgaW5wdXQgYW5kIHByb2Nlc3NlcyB0aGUgY29tbWFuZHMuXHJcbiAgICovXHJcblxyXG4gIC8vIHRoaXMgaXMgZm9yIG9uZVRpbWUgZW1wdHkgbG9hZCwgYnV0IGl0IGRvZXMgbm90IHF1aXRlIHdvcmtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIGFzeW5jIGZ1bmN0aW9uIGZldGNoRW1wdHlMb2FkKCkge1xyXG4gIC8vICAgICAvLyBjb25zdCByZXN0ID0gYXdhaXQgZmV0Y2goXHJcbiAgLy8gICAgIC8vICAgXCJodHRwOi8vbG9jYWxob3N0OjMyMzIvbG9hZGNzdj9maWxlcGF0aD1kYXRhL2NzdnRlc3QvZW1wdHkuY3N2XCJcclxuICAvLyAgICAgLy8gKTtcclxuICAvLyAgICAgLy8gY29uc3QganNvbiA9IHJlc3QuanNvbigpO1xyXG4gIC8vICAgICAvLyBjb25zdCBlbXB0eUZpbGU6IHN0cmluZ1tdW10gPSBhd2FpdCBqc29uW1wibG9hZGVkXCJdO1xyXG4gIC8vICAgICAvLyBwcm9wcy5zZXRGaWxlKGVtcHR5RmlsZSk7XHJcbiAgLy8gICAgIHNldEZpbGUoW1tdXSk7XHJcbiAgLy8gICB9XHJcbiAgLy8gICBmZXRjaEVtcHR5TG9hZCgpO1xyXG4gIC8vIH0sIFtdKTtcclxuXHJcbiAgLy8gdGhpcyBzaG91bGQgY2FsbCB0aGUgbWFwcGluZyBmcm9tIFJFUExGdW5jdGlvblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nOiBzdHJpbmcpIHtcclxuICAgIGxldCB2aWV3RmxhZyA9IGZhbHNlO1xyXG4gICAgc2V0Q291bnQoY291bnQgKyAxKTtcclxuICAgIGxldCBvdXRwdXQgPSBcIk91dHB1dDogXCI7XHJcbiAgICBsZXQgcmVzdWx0OiBzdHJpbmdbXVtdID0gW1tdXTtcclxuICAgIGxldCBzcGxpdElucHV0ID0gY29tbWFuZFN0cmluZy5zcGxpdChcIiBcIik7XHJcbiAgICAvLyB0aGlzIGlmIHN0YXRlbWVudCBpcyBuZWVkZWQgdG8gc3dpdGNoIHRvIHRoZSBtb2NrIG1vZGVcclxuICAgIGlmIChzcGxpdElucHV0WzBdID09IFwibW9ja1wiKSB7XHJcbiAgICAgIHNldE1vY2soIW1vY2spO1xyXG4gICAgICBpZiAobW9jaykge1xyXG4gICAgICAgIG91dHB1dCArPSBcInJlYWwgc2VydmVyXCI7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgb3V0cHV0ICs9IFwibW9jayBzZXJ2ZXJcIjtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgLy8gdGhpcyBpZiBzdGF0ZW1lbnQgY2hlY2tzIHRoZSBzdGF0ZSBvZiB0aGUgbW9jaywgYW5kIGRlY2lkZXMgd2hldGhlclxyXG4gICAgICAvLyB3ZSBhcmUgdXNpbmcgbW9ja2VkIGRhdGEgb3IgYWN0dWFsIEFQSSBjYWxsc1xyXG4gICAgICBpZiAoIW1vY2spIHtcclxuICAgICAgICBpZiAoc3BsaXRJbnB1dFswXSA9PSBcIm1vZGVcIikge1xyXG4gICAgICAgICAgc2V0TW9kZSghbW9kZSk7XHJcbiAgICAgICAgICBvdXRwdXQgKz0gaGFuZGxlTW9kZShtb2RlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgbGV0IHJlc3BvbnNlID0gYXdhaXQgY29tbWFuZEhhbmRsZXIoXHJcbiAgICAgICAgICAgIHNwbGl0SW5wdXRbMF0sXHJcbiAgICAgICAgICAgIHNwbGl0SW5wdXQuc2xpY2UoMSlcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBvdXRwdXQgKz0gcmVzcG9uc2VbMF07XHJcbiAgICAgICAgICByZXN1bHQgPSByZXNwb25zZVsxXTsgLy8gbWFrZSB0aGlzIHdvcmsgd2l0aCBzZXRGaWxlPyBXaWxsIGFsbG93IG1vY2tpbmc/XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIFdlIGtub3cgdGhhdCB0aGUgcHVycG9zZSBvZiByZWdpc3RyYXRpbmcgY29tbWFuZHMgaXMgdG8gZ2V0IHJpZCBvZiB0aGUgc3dpdGNoIGNhc2UsXHJcbiAgICAgICAgLy8gYnV0IHdlIGNvdWxkIG5vdCBmaWd1cmUgb3V0IGhvdyB0byBkbyBtb2NraW5nIHdpdGhvdXQgaXQuIFNvLCB3ZSBoYXZlIGEgbmljZSBhbmQgcHJldHR5IGhhbmRsaW5nXHJcbiAgICAgICAgLy8gb2YgdGhlIGlucHV0IGFib3ZlLCBhbmQgYSBiaXQgdWdsaWVyIHdheSB0byBoYW5kbGUgbW9jayBpbnB1dHMgaGVyZVxyXG4gICAgICAgIHN3aXRjaCAoc3BsaXRJbnB1dFswXSkge1xyXG4gICAgICAgICAgY2FzZSBcIm1vZGVcIjoge1xyXG4gICAgICAgICAgICBzZXRNb2RlKCFtb2RlKTtcclxuICAgICAgICAgICAgb3V0cHV0ICs9IGhhbmRsZU1vZGUobW9kZSk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgY2FzZSBcImxvYWRfZmlsZVwiOiB7XHJcbiAgICAgICAgICAgIGlmIChzcGxpdElucHV0Lmxlbmd0aCAhPSAyKSB7XHJcbiAgICAgICAgICAgICAgb3V0cHV0ICs9IFwiRXJyb3I6IGJhZCBmaWxlcGF0aCFcIjtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICBpZiAoaGFuZGxlTG9hZChzcGxpdElucHV0WzFdLCBwcm9wcykpIHtcclxuICAgICAgICAgICAgICAgIG91dHB1dCA9XHJcbiAgICAgICAgICAgICAgICAgIG91dHB1dCArIFwibG9hZF9maWxlIG9mIFwiICsgc3BsaXRJbnB1dFsxXSArIFwiIHN1Y2Nlc3NmdWwhXCI7XHJcbiAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIG91dHB1dCA9IG91dHB1dCArIFwiQ291bGQgbm90IGZpbmQgXCIgKyBzcGxpdElucHV0WzFdO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGNhc2UgXCJ2aWV3XCI6IHtcclxuICAgICAgICAgICAgLy9jYWxsIHZpZXdcclxuICAgICAgICAgICAgaWYgKHNwbGl0SW5wdXQubGVuZ3RoICE9IDEpIHtcclxuICAgICAgICAgICAgICBvdXRwdXQgKz1cclxuICAgICAgICAgICAgICAgIFwiRXJyb3I6IHZpZXcgb25seSB0YWtlcyBpbiAxIGFyZ3VtZW50LiBUYWtlIGNzMzIgYWdhaW4hXCI7XHJcbiAgICAgICAgICAgICAgLy8gYnJlYWs7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgaWYgKHByb3BzLmZpbGVbMF0ubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBjaGVjayBpZiB3ZSBuZWVkIHRoZSBpbmRleFxyXG4gICAgICAgICAgICAgICAgdmlld0ZsYWcgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgb3V0cHV0ICs9IFwiU3VjY2Vzc2Z1bCB2aWV3IVwiO1xyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBvdXRwdXQgKz0gXCJFcnJvcjogbm8gZmlsZXMgd2VyZSBsb2FkZWQuXCI7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgY2FzZSBcInNlYXJjaFwiOiB7XHJcbiAgICAgICAgICAgIGlmIChzcGxpdElucHV0Lmxlbmd0aCAhPT0gMykge1xyXG4gICAgICAgICAgICAgIG91dHB1dCArPSBcIkVycm9yOiBzZWFyY2ggbmVlZHMgdGhyZWUgYXJnc1wiO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIGlmIChwcm9wcy5maWxlWzBdLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gaGFuZGxlU2VhcmNoKHNwbGl0SW5wdXRbMV0sIHNwbGl0SW5wdXRbMl0pO1xyXG4gICAgICAgICAgICAgICAgb3V0cHV0ICs9IFwiU2VhcmNoaW5nISA6KVwiO1xyXG4gICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBvdXRwdXQgKz0gXCJFcnJvcjogc2VhcmNoIHJlcXVpcmVzIGEgbG9hZFwiO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGRlZmF1bHQ6IHtcclxuICAgICAgICAgICAgb3V0cHV0ID1cclxuICAgICAgICAgICAgICBvdXRwdXQgK1xyXG4gICAgICAgICAgICAgIFwiRXJyb3I6IGJhZCBjb21tYW5kLiBcIiArXHJcbiAgICAgICAgICAgICAgY29tbWFuZFN0cmluZyArXHJcbiAgICAgICAgICAgICAgXCIgaXMgbm90IGEgcmVhbCBjb21tYW5kXCI7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vZGVjaWRlIHdoYXQgdG8gcHJpbnQgYmFzZWQgb24gd2hhdCBoYXBwZW5lZCBiZWZvcmVcclxuICAgIGhhbmRsZU91dHB1dChwcm9wcywgbW9kZSwgb3V0cHV0LCBzcGxpdElucHV0LCByZXN1bHQsIHZpZXdGbGFnKTtcclxuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCI+XHJcbiAgICAgIDxmaWVsZHNldD5cclxuICAgICAgICA8bGVnZW5kPkVudGVyIGEgY29tbWFuZDo8L2xlZ2VuZD5cclxuICAgICAgICA8Q29udHJvbGxlZElucHV0XHJcbiAgICAgICAgICB2YWx1ZT17Y29tbWFuZFN0cmluZ31cclxuICAgICAgICAgIHNldFZhbHVlPXtzZXRDb21tYW5kU3RyaW5nfVxyXG4gICAgICAgICAgYXJpYUxhYmVsPXtcIkNvbW1hbmQgaW5wdXRcIn1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2ZpZWxkc2V0PlxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpfVxyXG4gICAgICAgIC8vYXJpYS1sYWJlbD1cImlucHV0IGJ1dHRvblwiXHJcbiAgICAgID5cclxuICAgICAgICBTdWJtaXR0ZWQge2NvdW50fSB0aW1lc1xyXG4gICAgICA8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuLypcclxuICogVGhpcyBmdW5jdGlvbiB3b3JrcyBvbiBjaGVja2luZyBpZiB0aGUgbG9hZGVkIGZpbGUgaXMgdmFsaWQgYW5kIHNldHMgdGhlIGRhdGEgdG8gYmUgdGhhdCBmaWxlIGlmIGl0IGlzLlxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGhhbmRsZUxvYWQocGF0aEZpbGU6IHN0cmluZywgcHJvcHM6IFJFUExJbnB1dFByb3BzKTogYm9vbGVhbiB7XHJcbiAgbGV0IGZpbGUgPSBkYXRhLmdldChwYXRoRmlsZSk7XHJcbiAgaWYgKGZpbGUgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgcHJvcHMuc2V0RmlsZShmaWxlKTtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbi8qXHJcbiAqIFRoaXMgZnVuY3Rpb24gd29ya3Mgd2l0aCBzd2l0Y2hpbmcgdGhlIG1vZGUgYW5kIGRvZXMgaXQsIGFzIHdlbGwgYXMgcmV0dXJucyB0aGUgb3V0cHV0XHJcbiAqIHN0YXRpbmcgd2hpY2ggbW9kZSB0aGUgdXNlciBzd2l0aGVkIHRvLlxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGhhbmRsZU1vZGUoc3RhdGU6IGJvb2xlYW4pOiBzdHJpbmcge1xyXG4gIGxldCBvdXRwdXQgPSBcIk1vZGUgc3dpdGNoZWQgdG8gXCI7XHJcbiAgaWYgKHN0YXRlKSB7XHJcbiAgICBvdXRwdXQgKz0gXCJ2ZXJib3NlXCI7XHJcbiAgfSBlbHNlIHtcclxuICAgIG91dHB1dCArPSBcImJyaWVmXCI7XHJcbiAgfVxyXG4gIHJldHVybiBvdXRwdXQ7XHJcbn1cclxuLypcclxuICogVGhpcyBmdW5jdGlvbiBoYW5kbGVzIHNlYXJjaCBhbmQgY2hlY2tzIGlmIHRoZSBrZXl3b3JkIGlzIHZhbGlkLFxyXG4gKiBhcyB3ZWxsIGFzIG91dHB1dHMgdGhlIHJlc3VsdCBvZiBzZWFyY2ggb3IgdGhlIGVycm9yIG1lc3NhZ2UuXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gaGFuZGxlU2VhcmNoKGFyZzE6IHN0cmluZywgYXJnMjogc3RyaW5nKTogc3RyaW5nW11bXSB7XHJcbiAgbGV0IHJlc3VsdCA9IHNlYXJjaGRhdGEuZ2V0KGFyZzEgKyBhcmcyKTtcclxuICBpZiAocmVzdWx0ICE9PSB1bmRlZmluZWQpIHtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbiAgfVxyXG4gIHJldHVybiBbXHJcbiAgICBbXCJFcnJvcjogXCIsIFwic2VhcmNoXCIsIFwiZmFpbGVkLiBcIiwgXCIgS2V5d29yZFwiLCBcIm5vdCBcIiwgXCJmb3VuZC5cIl0sXHJcbiAgICBbXCJBcmdzXCIsIGFyZzEsIGFyZzJdLFxyXG4gIF07XHJcbn1cclxuLyoqXHJcbiAqIFRoaXMgZnVuY3Rpb24gY29uc29saWRhdGVzIHRoZSBvdXRwdXQgYW5kIHdvcmtzIG9uIHByaW50aW5nIG91dCB0aGUgcmVzdWx0cyB0byB0aGUgaGlzdG9yeS5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBoYW5kbGVPdXRwdXQoXHJcbiAgcHJvcHM6IFJFUExJbnB1dFByb3BzLFxyXG4gIG1vZGU6IGJvb2xlYW4sXHJcbiAgb3V0cHV0OiBzdHJpbmcsXHJcbiAgY29tbWFuZDogc3RyaW5nW10sXHJcbiAgcmVzdWx0OiBzdHJpbmdbXVtdLFxyXG4gIHZpZXdmbGFnOiBib29sZWFuXHJcbik6IHZvaWQge1xyXG4gIGxldCBvdXRwdXRBcnJheTogc3RyaW5nW11bXTtcclxuICBsZXQgbmV3Q29tbWFuZCA9IFtcIkNvbW1hbmQ6IFwiXS5jb25jYXQoY29tbWFuZCk7XHJcbiAgb3V0cHV0QXJyYXkgPSBbbmV3Q29tbWFuZF07XHJcbiAgb3V0cHV0QXJyYXkgPSBvdXRwdXRBcnJheS5jb25jYXQoW291dHB1dC5zcGxpdChcIiBcIildKTtcclxuXHJcbiAgb3V0cHV0QXJyYXkgPSBvdXRwdXRBcnJheS5jb25jYXQocmVzdWx0KTtcclxuICBpZiAodmlld2ZsYWcpIHtcclxuICAgIG91dHB1dEFycmF5ID0gb3V0cHV0QXJyYXkuY29uY2F0KHByb3BzLmZpbGUpO1xyXG4gIH1cclxuXHJcbiAgaWYgKG1vZGUpIHtcclxuICAgIC8vZm9yIGJyaWVmIG1vZGVcclxuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmNvbW1hbmRzLCBvdXRwdXRBcnJheS5zbGljZSgxKV0pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICAvL2ZvciB2ZXJib3NlIG1vZGVcclxuICAgIHByb3BzLnNldEhpc3RvcnkoWy4uLnByb3BzLmNvbW1hbmRzLCBvdXRwdXRBcnJheV0pO1xyXG4gIH1cclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL2thcmF2L09uZURyaXZlL0RvY3VtZW50cy9DUzMyL3JlcGwtYmthcmF2YW4teXN0ZXBhbmUvZnJvbnQvc3JjL2NvbXBvbmVudHMvUkVQTElucHV0LnRzeCJ9