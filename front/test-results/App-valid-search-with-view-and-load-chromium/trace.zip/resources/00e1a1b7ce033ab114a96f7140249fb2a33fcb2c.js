import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba690a6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
import TableComponent from "/src/components/TableComponent.tsx";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", "aria-label": "Table that contains every output", tabIndex: 1, children: props.commands.map((command, index) => /* @__PURE__ */ jsxDEV(TableComponent, { data: command }, index, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLHistory.tsx",
    lineNumber: 18,
    columnNumber: 47
  }, this)) }, void 0, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLHistory.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJRO0FBdkJSLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNCLE9BQU9BLG9CQUFvQjtBQWNwQixnQkFBU0MsWUFBWUMsT0FBeUI7QUFDbkQsU0FDRSx1QkFBQyxTQUNDLFdBQVUsZ0JBQ1YsY0FBVyxvQ0FDWCxVQUFVLEdBRVRBLGdCQUFNQyxTQUFTQyxJQUFJLENBQUNDLFNBQVNDLFVBQzVCLHVCQUFDLGtCQUFlLE1BQU1ELFdBQWNDLE9BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEMsQ0FDM0MsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSjtBQUFDQyxLQVplTjtBQUFXLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJUYWJsZUNvbXBvbmVudCIsIlJFUExIaXN0b3J5IiwicHJvcHMiLCJjb21tYW5kcyIsIm1hcCIsImNvbW1hbmQiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xyXG5pbXBvcnQgVGFibGVDb21wb25lbnQgZnJvbSBcIi4vVGFibGVDb21wb25lbnRcIjtcclxuLyoqXHJcbiAqIFRoaXMgaXMgdGhlIGNvbXBvbmVudCB0aGF0IG1hbmFnZXMgdGhlIHNjcm9sbGFibGUgaGlzdG9yeSBieSBjcmVhdGluZyBhIFRhYmxlQ29tcG9uZW50IG9mIGFuIEhUTUxUYWJsZS5cclxuICovXHJcblxyXG4vKipcclxuICogVGhlIHByb3BzIGNvbnNpc3Qgb2YgY29tbWFuZHMgd2hpY2ggaXMgYSBzdHJpbmdbXVtdIHdoZXJlIHRoZSBjb21tYW5kcyBhcmUgcHJvY2Vzc2VkLlxyXG4gKi9cclxuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHMge1xyXG4gIGNvbW1hbmRzOiBzdHJpbmdbXVtdW107XHJcbn1cclxuLyoqXHJcbiAqIFRoaXMgZnVuY3Rpb24gY3JlYXRlcyB0aGUgdGFibGUgYW5kIG1hcHMgdGhlIGNvbW1hbmQgdG8gdGhlIGluZGV4IGFuZCBiaW5kIHRoZSBkYXRhIHRvIGl0LlxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIFJFUExIaXN0b3J5KHByb3BzOiBSRVBMSGlzdG9yeVByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPVwicmVwbC1oaXN0b3J5XCJcclxuICAgICAgYXJpYS1sYWJlbD1cIlRhYmxlIHRoYXQgY29udGFpbnMgZXZlcnkgb3V0cHV0XCJcclxuICAgICAgdGFiSW5kZXg9ezF9XHJcbiAgICA+XHJcbiAgICAgIHtwcm9wcy5jb21tYW5kcy5tYXAoKGNvbW1hbmQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgPFRhYmxlQ29tcG9uZW50IGRhdGE9e2NvbW1hbmR9IGtleT17aW5kZXh9IC8+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL2thcmF2L09uZURyaXZlL0RvY3VtZW50cy9DUzMyL3JlcGwtYmthcmF2YW4teXN0ZXBhbmUvZnJvbnQvc3JjL2NvbXBvbmVudHMvUkVQTEhpc3RvcnkudHN4In0=