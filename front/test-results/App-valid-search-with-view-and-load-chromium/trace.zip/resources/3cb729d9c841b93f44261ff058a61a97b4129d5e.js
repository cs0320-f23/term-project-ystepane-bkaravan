import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TableComponent.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba690a6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/TableComponent.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const TableComponent = ({
  data
}) => {
  return /* @__PURE__ */ jsxDEV("table", { className: "centered-table", children: /* @__PURE__ */ jsxDEV("tbody", { tabIndex: 0, children: data.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/TableComponent.tsx",
    lineNumber: 21,
    columnNumber: 43
  }, this)) }, rowIndex, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/TableComponent.tsx",
    lineNumber: 20,
    columnNumber: 38
  }, this)) }, void 0, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/TableComponent.tsx",
    lineNumber: 19,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/TableComponent.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_c = TableComponent;
export default TableComponent;
var _c;
$RefreshReg$(_c, "TableComponent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/TableComponent.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJjO0FBckJkLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFjekIsTUFBTUMsaUJBQWtDQSxDQUFDO0FBQUEsRUFBRUM7QUFBSyxNQUFNO0FBQ3BELFNBQ0UsdUJBQUMsV0FBTSxXQUFVLGtCQUNmLGlDQUFDLFdBQU0sVUFBVSxHQUNkQSxlQUFLQyxJQUFJLENBQUNDLEtBQUtDLGFBQ2QsdUJBQUMsUUFDRUQsY0FBSUQsSUFBSSxDQUFDRyxNQUFNQyxjQUNkLHVCQUFDLFFBQW9CRCxrQkFBWkMsV0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBCLENBQzNCLEtBSE1GLFVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBLENBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFSjtBQUFFRyxLQWRJUDtBQWdCTixlQUFlQTtBQUFlLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlRhYmxlQ29tcG9uZW50IiwiZGF0YSIsIm1hcCIsInJvdyIsInJvd0luZGV4IiwiY2VsbCIsImNlbGxJbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGFibGVDb21wb25lbnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuLyoqXHJcbiAqIFRoaXMgY29tcG9uZW50IGhhbmRsZXMgdGhlIHRhYmxlIGZvciBoaXN0b3J5LlxyXG4gKi9cclxuXHJcbi8qKlxyXG4gKiBUaGlzIGludGVyZmFjZSBpbmNsdWRlcyB0aGUgcHJvcCB1c2VkIGluIHRoZSBjb21wb25lbnQuXHJcbiAqL1xyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIGRhdGE6IHN0cmluZ1tdW107XHJcbn1cclxuLyoqXHJcbiAqIFRoaXMgY29tcG9uZW50IGlzIHVzZWQgdG8gY3JlYXRlIGEgdGFibGUgb3V0IG9mIHRoZSBzdHJpbmdbXVtdIGBkYXRhYC5cclxuICovXHJcbmNvbnN0IFRhYmxlQ29tcG9uZW50OiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBkYXRhIH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPHRhYmxlIGNsYXNzTmFtZT1cImNlbnRlcmVkLXRhYmxlXCI+XHJcbiAgICAgIDx0Ym9keSB0YWJJbmRleD17MH0+XHJcbiAgICAgICAge2RhdGEubWFwKChyb3csIHJvd0luZGV4KSA9PiAoXHJcbiAgICAgICAgICA8dHIga2V5PXtyb3dJbmRleH0+XHJcbiAgICAgICAgICAgIHtyb3cubWFwKChjZWxsLCBjZWxsSW5kZXgpID0+IChcclxuICAgICAgICAgICAgICA8dGQga2V5PXtjZWxsSW5kZXh9PntjZWxsfTwvdGQ+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC90cj5cclxuICAgICAgICApKX1cclxuICAgICAgPC90Ym9keT5cclxuICAgIDwvdGFibGU+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRhYmxlQ29tcG9uZW50O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL2thcmF2L09uZURyaXZlL0RvY3VtZW50cy9DUzMyL3JlcGwtYmthcmF2YW4teXN0ZXBhbmUvZnJvbnQvc3JjL2NvbXBvbmVudHMvVGFibGVDb21wb25lbnQudHN4In0=