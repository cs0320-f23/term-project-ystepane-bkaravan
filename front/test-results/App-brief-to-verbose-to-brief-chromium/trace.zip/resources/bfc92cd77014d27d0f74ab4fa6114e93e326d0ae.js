import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba690a6"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/App.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=3ba690a6"; const useEffect = __vite__cjsImport4_react["useEffect"];
import REPL from "/src/components/REPL.tsx";
function App() {
  _s();
  useEffect(() => {
    const detectKeyDown = (e) => {
      if (e.key === "CapsLock") {
        console.log("CapsLock is pressed. Calling zoom-in function...");
        document.body.style.fontSize = `${parseInt(getComputedStyle(document.body).fontSize) + 2}px`;
      } else if (e.key === "Control") {
        console.log("Ctrl key pressed. Calling zoom-out function...");
        document.body.style.fontSize = `${parseInt(getComputedStyle(document.body).fontSize) - 2}px`;
      }
    };
    document.addEventListener("keydown", detectKeyDown, true);
    return () => {
      document.removeEventListener("keydown", detectKeyDown, true);
    };
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "App-header", children: /* @__PURE__ */ jsxDEV("h1", { children: "REPL" }, void 0, false, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/App.tsx",
      lineNumber: 36,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/App.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPL, {}, void 0, false, {
      fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/App.tsx",
      lineNumber: 38,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/App.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
}
_s(App, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/karav/OneDrive/Documents/CS32/repl-bkaravan-ystepane/front/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRDUixPQUFPO0FBQ1AsU0FBU0EsaUJBQWlCO0FBQzFCLE9BQU9DLFVBQVU7QUFNakIsU0FBU0MsTUFBTTtBQUFBQyxLQUFBO0FBRWJILFlBQVUsTUFBTTtBQUNkLFVBQU1JLGdCQUFnQkEsQ0FBQ0MsTUFBdUI7QUFFNUMsVUFBSUEsRUFBRUMsUUFBUSxZQUFZO0FBQ3hCQyxnQkFBUUMsSUFBSSxrREFBa0Q7QUFDOURDLGlCQUFTQyxLQUFLQyxNQUFNQyxXQUFZLEdBQzlCQyxTQUFTQyxpQkFBaUJMLFNBQVNDLElBQUksRUFBRUUsUUFBUSxJQUFJLENBQ3REO0FBQUEsTUFFSCxXQUFXUCxFQUFFQyxRQUFRLFdBQVc7QUFDOUJDLGdCQUFRQyxJQUFJLGdEQUFnRDtBQUM1REMsaUJBQVNDLEtBQUtDLE1BQU1DLFdBQVksR0FDOUJDLFNBQVNDLGlCQUFpQkwsU0FBU0MsSUFBSSxFQUFFRSxRQUFRLElBQUksQ0FDdEQ7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUVBSCxhQUFTTSxpQkFBaUIsV0FBV1gsZUFBZSxJQUFJO0FBR3hELFdBQU8sTUFBTTtBQUNYSyxlQUFTTyxvQkFBb0IsV0FBV1osZUFBZSxJQUFJO0FBQUEsSUFDN0Q7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwyQkFBQyxPQUFFLFdBQVUsY0FDWCxpQ0FBQyxRQUFHLG9CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUs7QUFBQSxPQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUVKO0FBQUNELEdBbkNRRCxLQUFHO0FBQUFlLEtBQUhmO0FBcUNULGVBQWVBO0FBQUksSUFBQWU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIlJFUEwiLCJBcHAiLCJfcyIsImRldGVjdEtleURvd24iLCJlIiwia2V5IiwiY29uc29sZSIsImxvZyIsImRvY3VtZW50IiwiYm9keSIsInN0eWxlIiwiZm9udFNpemUiLCJwYXJzZUludCIsImdldENvbXB1dGVkU3R5bGUiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvQXBwLmNzc1wiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFJFUEwgZnJvbSBcIi4vUkVQTFwiO1xyXG5cclxuLyoqXHJcbiAqIFRoaXMgaXMgdGhlIGhpZ2hlc3QgbGV2ZWwgY29tcG9uZW50IVxyXG4gKi9cclxuXHJcbmZ1bmN0aW9uIEFwcCgpIHtcclxuICAvLyB0cmFja2luZyBrZXkgcHJlc3NpbmcgZm9yIHpvb21pbmdcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZGV0ZWN0S2V5RG93biA9IChlOiB7IGtleTogc3RyaW5nIH0pID0+IHtcclxuICAgICAgLy9pZiBzb21lb25lIGlzIHByZXNzaW5nIGRvd24gc2hpZnQsIHdlIGFyZSB6b29taW5nIGluXHJcbiAgICAgIGlmIChlLmtleSA9PT0gXCJDYXBzTG9ja1wiKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJDYXBzTG9jayBpcyBwcmVzc2VkLiBDYWxsaW5nIHpvb20taW4gZnVuY3Rpb24uLi5cIik7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5mb250U2l6ZSA9IGAke1xyXG4gICAgICAgICAgcGFyc2VJbnQoZ2V0Q29tcHV0ZWRTdHlsZShkb2N1bWVudC5ib2R5KS5mb250U2l6ZSkgKyAyXHJcbiAgICAgICAgfXB4YDtcclxuICAgICAgICAvLyBpZiBzb21lb25lIGlzIHByZXNzaW5nIGRvd24gY29udHJvbCwgd2UgYXJlIHpvb21pbmcgb3V0XHJcbiAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09IFwiQ29udHJvbFwiKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJDdHJsIGtleSBwcmVzc2VkLiBDYWxsaW5nIHpvb20tb3V0IGZ1bmN0aW9uLi4uXCIpO1xyXG4gICAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUuZm9udFNpemUgPSBgJHtcclxuICAgICAgICAgIHBhcnNlSW50KGdldENvbXB1dGVkU3R5bGUoZG9jdW1lbnQuYm9keSkuZm9udFNpemUpIC0gMlxyXG4gICAgICAgIH1weGA7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgZGV0ZWN0S2V5RG93biwgdHJ1ZSk7XHJcblxyXG4gICAgLy8gQ2xlYW51cCB0aGUgZXZlbnQgbGlzdGVuZXJcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGRldGVjdEtleURvd24sIHRydWUpO1xyXG4gICAgfTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIkFwcFwiPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJBcHAtaGVhZGVyXCI+XHJcbiAgICAgICAgPGgxPlJFUEw8L2gxPlxyXG4gICAgICA8L3A+XHJcbiAgICAgIDxSRVBMIC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMva2FyYXYvT25lRHJpdmUvRG9jdW1lbnRzL0NTMzIvcmVwbC1ia2FyYXZhbi15c3RlcGFuZS9mcm9udC9zcmMvY29tcG9uZW50cy9BcHAudHN4In0=